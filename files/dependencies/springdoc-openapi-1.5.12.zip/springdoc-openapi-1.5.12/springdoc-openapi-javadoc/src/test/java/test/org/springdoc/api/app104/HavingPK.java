package test.org.springdoc.api.app104;

/**
 * The type Having pk.
 */
public class HavingPK {
}
