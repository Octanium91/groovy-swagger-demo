package test.org.springdoc.api.app129;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The type Actual returned entity.
 */
public class ActualReturnedEntity {

	/**
	 * The Result.
	 */
	@JsonProperty
	String result;

}
