/*
 *
 *  *
 *  *  *
 *  *  *  * Copyright 2019-2020 the original author or authors.
 *  *  *  *
 *  *  *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  *  *  * you may not use this file except in compliance with the License.
 *  *  *  * You may obtain a copy of the License at
 *  *  *  *
 *  *  *  *      https://www.apache.org/licenses/LICENSE-2.0
 *  *  *  *
 *  *  *  * Unless required by applicable law or agreed to in writing, software
 *  *  *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  *  *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  *  *  * See the License for the specific language governing permissions and
 *  *  *  * limitations under the License.
 *  *  *
 *  *
 *
 *
 */

package test.org.springdoc.api.app14;

import java.util.Optional;

import org.springdoc.core.converters.models.Pageable;
import org.springdoc.core.customizers.DelegatingMethodParameterCustomizer;
import org.springdoc.data.rest.SpringDocDataRestConfiguration;
import org.springdoc.data.rest.customisers.DataRestDelegatingMethodParameterCustomizer;
import test.org.springdoc.api.AbstractSpringDocTest;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.data.rest.RepositoryRestMvcAutoConfiguration;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.rest.core.config.RepositoryRestConfiguration;
import org.springframework.test.context.TestPropertySource;

import static org.springdoc.core.SpringDocUtils.getConfig;

@TestPropertySource(properties = { "spring.data.web.pageable.default-page-size=25",
		"spring.data.web.pageable.page-parameter=pages",
		"spring.data.web.pageable.size-parameter=sizes",
		"spring.data.web.sort.sort-parameter=sorts" })
@EnableAutoConfiguration(exclude = {
		RepositoryRestMvcAutoConfiguration.class, SpringDocDataRestConfiguration.class
})
public class SpringDocApp14Test extends AbstractSpringDocTest {

	static {
		getConfig().replaceParameterObjectWithClass(org.springframework.data.domain.Pageable.class, Pageable.class)
				.replaceParameterObjectWithClass(org.springframework.data.domain.PageRequest.class, Pageable.class);
	}


	@SpringBootApplication
	static class SpringDocTestApp {
		// We only need to test spring-web with Pageable, without the use of spring-data-rest-starter
		@Bean
		@ConditionalOnMissingBean
		@Lazy(false)
		DelegatingMethodParameterCustomizer delegatingMethodParameterCustomizer(Optional<SpringDataWebProperties> optionalSpringDataWebProperties, Optional<RepositoryRestConfiguration> optionalRepositoryRestConfiguration) {
			return new DataRestDelegatingMethodParameterCustomizer(optionalSpringDataWebProperties, optionalRepositoryRestConfiguration);
		}
	}

}