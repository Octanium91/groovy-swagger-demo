package test.org.springdoc.api.app7.application;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Foo {
  String foo;
}
