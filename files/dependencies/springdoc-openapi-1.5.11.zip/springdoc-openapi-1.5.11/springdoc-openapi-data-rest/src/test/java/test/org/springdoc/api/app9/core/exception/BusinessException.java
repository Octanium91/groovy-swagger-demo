package test.org.springdoc.api.app9.core.exception;

public class BusinessException extends Exception {

	private static final long serialVersionUID = -5454643285401132760L;

	public BusinessException(String message) {
		super(message);
	}

}
