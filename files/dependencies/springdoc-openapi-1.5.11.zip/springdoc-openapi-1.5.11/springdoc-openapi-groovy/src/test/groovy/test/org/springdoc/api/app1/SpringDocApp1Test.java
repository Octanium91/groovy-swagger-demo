package test.org.springdoc.api.app1;

import test.org.springdoc.api.AbstractSpringDocTest;

import org.springframework.boot.autoconfigure.SpringBootApplication;

public class SpringDocApp1Test extends AbstractSpringDocTest {
	@SpringBootApplication
	static class SpringDocTestApp {}
}
