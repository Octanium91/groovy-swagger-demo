package test.org.springdoc.api.app104;

/**
 * The type Design.
 */
public class Design extends HavingPK {
}
